import sys
sys.path.insert(1, 'PreprocessingFunctionality')

from asPLS import *
from HuberDenoisingChambollePock import *
from WhitakerHayes import *